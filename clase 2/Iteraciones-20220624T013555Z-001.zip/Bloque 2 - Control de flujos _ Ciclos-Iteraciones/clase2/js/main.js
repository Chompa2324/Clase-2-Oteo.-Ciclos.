// Condición verdadera
/* if (true) {
    console.log("Vas a ver este mensaje!");
}

// Condición false
if (false) {
    console.log("No vas a ver este mensaje!");
} */



/* let unNumero = 5;

// Comparamos el valor de la variable con 5
if (unNumero == 5) {
    console.log("Vas a ver este mensaje!");
}

// Comparamos el valor de la variable con 6
if (unNumero == 6) {
    console.log("No vas a ver este mensaje!");
} */

/* let edad = parseInt(prompt("Cúal es tu edad?"));

if (edad >= 18) {
    console.log("Sos mayor de edad. Podes pasar!");
} else {
    console.log("Sos MENOR de edad. NO PODES pasar!");
} */




/* let unColor = prompt("Ingresa tu color preferido:");

// Comparamos el valor de la variable con Rojo
if (unColor == "Rojo") {
    console.log("1- El color es Rojo!");
} else {
    console.log("2- El color no es Rojo!");
}

if (unColor != "Rojo") {
    console.log("3- El color no es Rojo!");
} else {
    console.log("4- El color es Rojo!");
} */



/* let nombreUsuario = prompt("Ingrese su Nombre de Usuario");

if (nombreUsuario == null) {
    alert("1- No ingresaste tu Nombre de Usuario!");
} else if (nombreUsuario == "") {
    alert("1- El Usuario ingresado está vacío!");
} else {
    alert("1- El Usuario ingresado es: " + nombreUsuario);
}

if (nombreUsuario != null) {
    alert("2- El Usuario ingresado es: " + nombreUsuario);
} else {
    alert("2- No ingresaste tu Nombre de Usuario!");
} */



/* let precio = 40;

if (precio < 20) {
    alert("El precio es menor que 20");
} else if (precio < 50) {
    alert("El precio es menor que 50");
} else if (precio < 100) {
    alert("El precio es menor que 100");
} else {
    alert("El precio es mayor o igual a 100");
} */


// Otro ejemplo
/* let temperatura = parseFloat(prompt("Ingresa la temperatura de tu Ciudad"));

if (temperatura <= 0) {
    alert("El clima esta congelante. Por favor usá un abrigo!");
} else if (temperatura <= 10) {
    alert("El clima está frío!");
} else if (temperatura <= 20) {
    alert("El clima está bien, pero podría mejorar!");
} else if (temperatura <= 30) {
    alert("El clima está excelente!");
} else if (temperatura <= 40) {
    alert("El clima está muy caluroso. Por favor, salí con un gorro y una botella de agua");
} else {
    alert("NO SALGAS DE TU CASA!");
} */



// True o False
/* let nombre = "10";
let numero = 10;
let esMayor5 = (numero > 5);
console.log(typeof nombre);
console.log(nombre);
console.log(typeof numero);
console.log(numero);
console.log(typeof esMayor5);
console.log(esMayor5);

if (esMayor5) {
    alert("Es Boolean True!");
} else {
    alert("No se cumplió la condición");
} */

/* let estado_civil = prompt("Estás en pareja? (SI/NO)");
let resultado = (estado_civil == "si");
console.log(typeof resultado);

if (resultado) {
    alert("ESTAS EN PAREJA. PORTATE BIEN!");
} else {
    alert("PORTATE MAL!");
} */


// Operadores Lógicos
let a = 8;
let b = 4;
let c = 3 + 2;
let d = parseInt(a) + b;


// A es igual B
/* if (a == b) {
    console.log("A es igual a B!");
}

// A es estrictamente igual que B
if (a === b) {
    console.log("A es estrictamente igual a B!");
} 
 
// A es distinto de B
if (a != b) {
    console.log("A es distinto de B!");
}

// A es estrictamente distinto de B
if (a !== b) {
    console.log("A es estrictamente distinto de B!");
} */

// A es menor o igual que B
/* if (a <= b) {
    console.log("A es menor o igual que B!");
}

// A es mayor o igual que B
if (a >= b) {
    console.log("A es mayor o igual que B!");
}  */

/* if ((a == 10) && (b == 10)) {
    console.log("A y B valen igual a 10!");
}

if (a == 10 || b == 10) {
    console.log("A o B valen igual a 10!");
} */

/* if (!((a == 5) || (a == 6))) {
    console.log("A es distinto de 5!");
}

if (a != 5) {
    console.log("A es distinto de 5!");
} */


/* let nombre = prompt("Cúal es tu Nombre?");
let apellido = prompt("Cúal es tu Apellido?");

if ((nombre != null) && (apellido != null)) {
    alert("Su Nombre y Apellido es: " + nombre + " " + apellido);
} else {
    alert("Ingrese su Nombre y Apellido!");
} */



/* let nombreIngresado = prompt("Ingrese su Nombre");

if ((nombreIngresado == "ana") || (nombreIngresado == "ANA") || (nombreIngresado == "Ana") || (nombreIngresado == "HANNAH")) {
    alert("El nombre ingresado es Ana!");
} else {
    alert("El nombre ingresado no es Ana!");
} */



let nombreIngresado = prompt("Ingrese su Nombre");
let edadIngresada = parseInt(prompt("Ingrese su Edad")); //Convertimos valores enteros

if ((edadIngresada >= 18) && ((nombreIngresado == "ana") || (nombreIngresado == "ANA"))) {
    alert("1- El nombre ingresado es Ana!");
} else {
    alert("1- El nombre ingresado no es Ana!");
}

if (((edadIngresada >= 18) && (nombreIngresado == "ana")) || (nombreIngresado == "ANA")) {
    alert("2- El nombre ingresado es Ana!");
} else {
    alert("2- El nombre ingresado no es Ana!");
}

if ((edadIngresada >= 18) && (nombreIngresado == "ana")) {
    alert("3- El nombre ingresado es Ana!");
} else {
    alert("3- El nombre ingresado no es Ana!");
}