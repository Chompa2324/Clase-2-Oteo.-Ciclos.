// Ejemplo For #1
/* for (let i=0; i<10; i++) {
    console.log("El valor de 'i' es: " + i);
    alert(i);
} */

// Ejemplo For #2
/* for (let i=-10; i<=10; i++) {
    console.log("El valor de 'i' es: " + i);
} */

// For contando en inversa
/* for (let i=10; i>=1; i--) {
    alert("El valor de i es: " + i);
} */

// Saltos de 2 en 2
/* for (let i=0; i<=10; i+=2) {
    alert("El valor de i es: " + i);
} */


// Ejemplo en clase
/* let total_pagar = 0;
let cant_productos = parseInt(prompt("Ingrese la cantidad de productos:"));
let limite = 500;

for (let i=0; i<cant_productos; i++) {
    let nombre_producto = prompt("Ingrese el Nombre del Producto:");
    let precio_producto = parseFloat(prompt("Ingrese el Precio del Producto:"));
    total_pagar += precio_producto;
    let mensaje = "Ingresaste: " + nombre_producto + " por $" + precio_producto;
    alert(mensaje);
    console.log(mensaje);

    if (total_pagar > limite) {
        alert("TE PASASTE DEL LIMITE!");
        break;
    }
    //total_pagar = total_pagar + precio_producto;
}

let mensaje_final = "El total a pagar es: $" + total_pagar;
alert(mensaje_final);
console.log(mensaje_final); */



// Ejemplo Tablas
/* let ingresarNumero = parseInt(prompt("Ingresar Número:")); //5

for (let i=0; i<=10; i++) {
    let resultado = ingresarNumero * i;
    alert(ingresarNumero + " X " + i + " => " + resultado);
} */

//Ejemplo Turnos
/* for (let i=1; i<=5; i++) {
    let ingresarNombre = prompt("Ingrese Nombre:");
    alert("Turno Nº: " + i + " - Nombre: " + ingresarNombre);
} */


// Sentencia Break
/* for (let i=1; i<=10; i++) {
    console.log("Hola #" + i);

    if (i == 5) {
        console.log("Entré al break!");
        break;
    }

    alert("Hola #" + i);
} */

/* let inicio = 1;
let nombres = parseInt(prompt("Ingrese la cantidad de Nombres que quiera mostrar!"));

for (i = inicio; i<=nombres; i++) {
    let ingresarNombre = prompt("Ingrese Nombre:");

    if (ingresarNombre == "Santiago") {
        alert("Hola, " + ingresarNombre + "!");
        break;
    }

    alert("Turno Nº: " + i + " - Nombre: " + ingresarNombre);
}

alert("Estoy por fuera del FOR!"); */



// Sentencia Continue
/* for (let i=1; i<=10; i++) {
    console.log("Hola #" + i);

    if (i == 5) {
        console.log("Entré al Continue!");
        continue;
    }
    
    console.log("Chau #" + i);
} */



// While
/* let repetir = true;
let i = 0;

while (repetir) {
    console.log("Al infinito ...");
    
    if (i == 5) {
        console.log("Entré al Break!");
        repetir = false;
        //break;
    }

    alert("Hola! #" + i);
    i++;
}

alert("Finalizo el ciclo del While!"); */


// While con ESC
/* let entrada = prompt("Ingrese un dato. Escriba 'ESC' para salir.");

while (entrada.toUpperCase() != "ESC") {
    alert("El usuario ingresó: " + entrada);

    entrada = prompt("Ingrese otro dato. Escriba 'ESC' para salir.");
} */

/* let limite = 5000;
let suma_total = 0;
let nombre_producto = "";
let precio_producto = 0;
let recargo = 0;

while (nombre_producto.toUpperCase() != "ESC") {
    nombre_producto = prompt("Ingrese el Nombre del Producto: ESC para salir");
    precio_producto = parseInt(prompt("Ingrese el Valor del Producto: "));
    suma_total += precio_producto;

    if ((nombre_producto == "") || (nombre_producto == null)) {
        alert("Ingresaste un Nombre vacío!");
        break;
    }

    if ((precio_producto == "") || (precio_producto == null)) {
        alert("Ingresaste un Precio vacío!");
        break;
    }

    if (suma_total > limite) {
        alert("Superaste el límite!");
        recargo = (suma_total - limite) * 1.2;
        break;
    }

    alert("Ingresaste: " + nombre_producto + " $" + precio_producto);
    console.log("Total: " + suma_total);
}

alert("El total es: $" + suma_total);

if (recargo > 0) {
    alert("Vas a tener que abonar, como recargo: $" + recargo);
} */



// Do While
/* let numero;

do {
    numero = prompt("Ingresar Número:");
    console.log(numero);
} while (parseInt(numero)); */



/* let numero = prompt("Ingresar Número:");
let intentos = 3;
    
while (parseInt(numero)) {
    if (intentos == 0) {
        alert("Ingresaste la cantidad máxima permitida!");
        break;
    }

    console.log("El número ingresado es: " + numero);
    numero = prompt("Ingresar Número:");

    intentos--;
} */



// Switch
/* let numero = parseInt(prompt("Cual es tu edad?"));

switch(numero) {
    case 5:
        alert("Sos un niño!");
        break;
    case 13:
        alert("Sos un adolescente!");
        break;
    case 18:
        alert("Sos Mayor de Edad!");
        break;
    default:
        alert("Sos un viejo!");
        break;  
} */

/* if ((numero >= 0) && (numero <= 10)) {
    alert("Sos un niño!");
} else if ((numero >= 11) && (numero <= 17)) {
    alert("Sos un adolescente!");
} else if ((numero >= 18) && (numero <= 60)) {
    alert("Sos un adulto!");
} else {
    alert("Sos un viejo!");
} */


/* let pregunta;
let verdadero = true;

while (verdadero) {
    pregunta = prompt("Ingrese un valor");

    switch(pregunta) {
        case "ESC":
            alert("Pulsaste ESC");
            verdadero = false;
            break;
        case "EXIT":
            alert("Pulsaste EXIT");
            verdadero = false;
            break;
        case "SALIR":
            alert("Pulsaste SALIR");
            verdadero = false;
            break;
        default:
            console.log(pregunta);
            break;
    }  
}  */

 /* if (pregunta == "ESC") {
        alert("Pulsaste ESC");
        verdadero = false;
    } else if (pregunta == "EXIT") {
        alert("Pulsaste SALIR");
        verdadero = false;
    } else if (pregunta == "SALIR") {
        alert("Pulsaste SALIR");
        verdadero = false;
    } else {
        console.log(pregunta);
    } */

/* let nombre = prompt("Ingrese su Nombre:").toUpperCase();

while (nombre != "ESC") {
    switch(nombre) {
        case "ANA":
            alert("Hola Ana!");
            break;
        case "JUAN":
            alert("Hola Juan!");
            break;
        default:
            alert("Quién sos?");
            break;
    }

    nombre = prompt("Ingrese un Nombre:").toUpperCase();
} */



// Ejemplo práctico en clase
// Calculadora de Indice de Masa Corporal
let edad = parseInt(prompt("Ingrese su Edad:"));

while (edad < 18) {
    edad = parseInt(prompt("Ingrese su Edad:"));
}

let sexo = prompt("Ingrese su Sexo: (M/F/NB)").toUpperCase();

while (!((sexo == "M") || (sexo == "F") || (sexo == "NB"))) {
    sexo = prompt("Ingrese su Sexo: (M/F/NB)").toUpperCase();
}

let altura = prompt("Ingrese su [ALTURA] en Mts.:");
let peso = prompt("Ingrese su [PESO] en Kg.:");
console.log("Edad: " + edad);
console.log("Sexo: " + sexo);
console.log("Altura: " + altura);
console.log("Peso: " + peso);

altura = parseFloat(altura.replace(",", "."));
peso = parseFloat(peso.replace(",", "."));
console.log("Altura: " + altura);
console.log("Peso: " + peso);

if (peso < 35) {
    alert("Consulte inmediante a un Médico!");
}

// Calculo del Peso
let imc = (peso / (altura * altura)).toFixed(2);
console.log(imc);
let mensaje = "";

if (imc < 18.5) {
    mensaje = "Tu Peso inferior al normal";
} else if ((imc >= 18.5) && (imc <= 24.9)) {
    mensaje = "Tu Peso inferior al normal";
} else if ((imc >= 25) && (imc <= 29.9)) {
    mensaje = "Tu Peso superior al normal";
} else {
    mensaje = "Tenés Obesidad!";
}

alert("Tu IMC es: " + imc + "%")
alert(mensaje);